CREATE TABLE bestsellers(
Name varchar(150),
Author varchar(150),
Rating numeric,
Reviews integer,
Price integer,
Year integer,
Genre varchar(150)
);