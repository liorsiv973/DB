with recursive r as
   (
-- (   select 1, *
--     from movies
--         natural join playsIn as P1 natural join playsIn as P2
--         join actors as A1 on (P1.actorId = A1.actorId)
--         join actors as A2 on (P1.actorId = A2.actorId)
       select distinct *
       from actors natural join playsin p1 natural join
                            (select movieid, actorid as actorid2
                            from playsin) as T natural join movies
       where (p1.actorid != actorid2)
)

select * from r;

