select actorId, name
from movies natural join actors natural join playsIn
group by actorId, name
HAVING avg(rating) >= ALL(
    select avg(rating)
    from movies natural join actors natural join playsIn
    where rating is not null
    group by actorId
    )
;