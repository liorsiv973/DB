select count(*) as Num
from (
         select actorId
         from (
                  select movieId
                  from playsIn
                  group by movieId
                  having count(*) >= 6) as T1
                  natural join playsIn
     except

        select actorId
        from (
          select movieId
          from playsIn
          group by movieId
          having count(*) < 6) as T2
          natural join playsIn

) as T
;