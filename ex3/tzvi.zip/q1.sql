select actorId, max(duration) ,min(duration), avg(duration)
from playsIn natural join movies
group by actorId
order by actorId;