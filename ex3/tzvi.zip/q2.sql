select movieId, title
from playsIn natural join movies natural join actors
group by movieId, title
HAVING avg(movies.year - actors.byear) >= 70
;
