SELECT COUNT(*) AS num
FROM(
		SELECT actorId
		FROM (
				SELECT movieId
				FROM PlaysIn
				GROUP BY movieId
				HAVING COUNT(*) >=6) AS SIXACT NATURAL JOIN playsIn		
	EXCEPT
		SELECT actorId
		FROM (
					SELECT movieId
					FROM PlaysIn
					GROUP BY movieId
					HAVING COUNT(*) <6) AS NOTSIXACT NATURAL JOIN playsIn
	) AS my_num;