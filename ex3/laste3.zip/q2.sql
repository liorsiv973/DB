SELECT distinct movieid, title
FROM actors NATURAL JOIN movies NATURAL JOIN playsIn
GROUP BY movieid, title
HAVING AVG(movies.year- actors.byear) >= 70
ORDER BY movieid;
