drop table won;
drop table medal;
drop table participation;
drop table athlete;
drop table team;


